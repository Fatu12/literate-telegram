console.log("hello");
var x = 20
var y = x + 5
console.log(y)
